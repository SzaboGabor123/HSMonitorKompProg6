﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.Management;

namespace HSMonitorkompprog
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {

        System.Windows.Threading.DispatcherTimer timer = new System.Windows.Threading.DispatcherTimer();

        public MainWindow()
        {
            InitializeComponent();
            timer.Tick += new EventHandler(Timer_Tick);
            timer.Interval = new TimeSpan(0, 0, 1);
            timer.Start();

            GetBattery();
            GetOSInfo();
            GetProcessorInfo();
            GetGPUInfo();
            GetMemoInfo();
            GetAudioInfo();
            GetDiskInfo();
            GetBoardInfo();
        }

        private void Timer_Tick(object sender, EventArgs e)
        {
            GetTime();
        }

        private void GetTime()
        {
            DateTime date;
            date = DateTime.Now;
            LblClock.Text = date.ToLongTimeString() + "  " + date.ToLongDateString();
        }

        private void GetBattery()
        {
            System.Management.ManagementClass wmi = new System.Management.ManagementClass("Win32_Battery");
            var providers = wmi.GetInstances();

            foreach (var provider in providers)
            {
                int batteryStatus = Convert.ToInt16(provider["BatteryStatus"]);

                if (batteryStatus == 0)
                {
                    LblBatteryStatus.Text = "Akkumulátor töltöttsége:" + " " + "Egyéb";
                }
                if (batteryStatus == 1)
                {
                    LblBatteryStatus.Text = "Akkumulátor töltöttsége:" + " " + "Ismeretlen";
                }
                if (batteryStatus == 2)
                {
                    LblBatteryStatus.Text = "Akkumulátor töltöttsége:" + " " + "Teljesen feltöltve";
                }
                if (batteryStatus == 3)
                {
                    LblBatteryStatus.Text = "Akkumulátor töltöttsége:" + " " + "Alacsony töltöttség";
                }
                if (batteryStatus == 4)
                {
                    LblBatteryStatus.Text = "Akkumulátor töltöttsége:" + " " + "Kritikus töltöttség";
                }
                if (batteryStatus == 5)
                {
                    LblBatteryStatus.Text = "Akkumulátor töltöttsége:" + " " + "Töltés";
                }
                if (batteryStatus == 6)
                {
                    LblBatteryStatus.Text = "Akkumulátor töltöttsége:" + " " + "Töltés és magas";
                }
                if (batteryStatus == 7)
                {
                    LblBatteryStatus.Text = "Akkumulátor töltöttsége:" + " " + "Töltés és alacsony";
                }
                if (batteryStatus == 8)
                {
                    LblBatteryStatus.Text = "Akkumulátor töltöttsége:" + " " + "Töltés és kritikus";
                }
                if (batteryStatus == 9)
                {
                    LblBatteryStatus.Text = "Akkumulátor töltöttsége:" + " " + "Nem meghatározott";
                }
                if (batteryStatus == 10)
                {
                    LblBatteryStatus.Text = "Akkumulátor töltöttsége:" + " " + "Részben feltöltve";
                }
            }
        }

        private void GetOSInfo()
        {
            System.Management.ManagementClass wmi = new System.Management.ManagementClass("Win32_ComputerSystem");
            var providers = wmi.GetInstances();
            foreach (var provider in providers)
            {
                string Name = provider["Name"].ToString();
                LblSystemName.Text = Name.ToString();
            }
            foreach (var provider in providers)
            {
                string systemSKU = provider["SystemSKUNumber"].ToString();
                LblSystemSku.Text = systemSKU.ToString();
            }
        }

        private void GetProcessorInfo()
        {
             System.Management.ManagementClass wmi = new System.Management.ManagementClass("Win32_Processor");
             var providers = wmi.GetInstances();

             foreach (var provider in providers)
             {
                int procFamily = Convert.ToInt32(provider["Family"]);
                int procSpeed = Convert.ToInt32(provider["CurrentClockSpeed"]);
                int procMag = Convert.ToInt32(provider["ThreadCount"]);
                string procStatus = provider["status"].ToString();
                string procName = provider["Name"].ToString();
                Boolean powerManagementSupported = Convert.ToBoolean(provider["PowerManagementSupported"]);

                LblProcStatus.Text = procStatus.ToString();
                LblClockSpeed.Text = procSpeed.ToString() + " " + "MHz";
                LblProcFamily.Text = procFamily.ToString();
                LblProcName.Text = procName.ToString();
                LblProcMag.Text = procMag.ToString();

                if (powerManagementSupported == true)
                {
                    LblProcPowerMan.Text = "Az energiagazdálkodás engedélyezve van.";
                }
                else if (powerManagementSupported == false)
                {
                    LblProcPowerMan.Text = "Az energiagazdálkodás nem felügyelt.";
                }
             }
        }

        private void GetGPUInfo()
        {
            System.Management.ManagementClass wmi = new System.Management.ManagementClass("Win32_VideoController");
            var providers = wmi.GetInstances();

            foreach (var provider in providers)
            {
                string VideoCardName = provider["Name"].ToString();
                string VideoCardDriver = provider["DriverVersion"].ToString();

                LblGPUName.Text = VideoCardName.ToString();
                LblGPUDriver.Text = VideoCardDriver.ToString();
            }
        }

        private void GetMemoInfo()
        {
            System.Management.ManagementClass wmi = new System.Management.ManagementClass("Win32_PhysicalMemory");
            var providers = wmi.GetInstances();

            foreach (var provider in providers)
            {
                long MemoCap = Convert.ToInt64(provider["Capacity"]);
                int MemoSpeed = Convert.ToInt32(provider["Speed"]);
                string MemoModel = provider["Name"].ToString();

                LblMemoCap.Text = MemoCap.ToString() + " " + "byte";
                LblMemoSpeed.Text = MemoSpeed.ToString() + " " + "MHz";
                LblMemoModel.Text = MemoModel.ToString();
            }
        }

        private void GetAudioInfo()
        {
            System.Management.ManagementClass wmi = new System.Management.ManagementClass("Win32_SoundDevice");
            var providers = wmi.GetInstances();

            foreach (var provider in providers)
            {
                string AudioModel = provider["ProductName"].ToString();
                string AudioManufact = provider["Manufacturer"].ToString();

                LblAudioName.Text = AudioModel.ToString();
                LblAudioManu.Text = AudioManufact.ToString();
            }
        }

        private void GetDiskInfo()
        {
            System.Management.ManagementClass wmi = new System.Management.ManagementClass("Win32_DiskDrive");
            var providers = wmi.GetInstances();

            foreach (var provider in providers)
            {
                string DiskName = provider["Model"].ToString();
                long DiskSize = Convert.ToInt64(provider["Size"]);

                LblDiskName.Text = DiskName.ToString();
                LblDiskSize.Text = DiskSize.ToString() + " " + "byte";
            }
        }

        private void GetBoardInfo()
        {
            System.Management.ManagementClass wmi = new System.Management.ManagementClass("Win32_BaseBoard");
            var providers = wmi.GetInstances();

            foreach (var provider in providers)
            {
                string BoardModel = provider["Product"].ToString();
                string BoardManu = provider["Manufacturer"].ToString();

                LblBoardName.Text = BoardModel.ToString();
                LblBoardManu.Text = BoardManu.ToString();
            }
        }
    }
}
